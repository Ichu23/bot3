from info import USER_SESSION, API_ID, API_HASH       
from pyrogram import Client

User = Client(
    name="userbot",
    api_id=API_ID,
    api_hash=API_HASH,
    session_string=USER_SESSION,
    )
